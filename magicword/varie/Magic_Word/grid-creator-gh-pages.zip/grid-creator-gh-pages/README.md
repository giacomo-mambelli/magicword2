# grid-creator
Benchmarking grid creation time in js
